#!/bin/sh
BITRATE=`expr $2 \\* 1000`
ifconfig $1 down
ifconfig $1 txqueuelen 1000
ip link set $1 type can restart-ms 1000
#echo ip link set $1 type can bitrate $BITRATE
ip link set $1 type can bitrate $BITRATE
ifconfig $1 up