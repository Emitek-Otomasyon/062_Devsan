import QtQuick 2.5
import QtQuick.Controls 1.4
import QtQuick.Window 2.0

Rectangle {
	objectName: "rectangle"
	id: window
	anchors.fill: parent
	visible: true
	color: "transparent"
}