import QtQuick 2.5
import QtQuick.Controls 1.4
import QtQuick.Window 2.0

Rectangle {
	objectName: "rectangle"
	id: window
	anchors.fill: parent
	visible: true
	
	signal destruct()

	ScrollView {
		id: scroll
		objectName: "scroll"
		clip: true
		anchors.fill: parent
		signal scrollChanged(int hPos, int vPos)
		flickableItem.onMovementEnded: {
			scrollChanged(flickableItem.contentX, flickableItem.contentY)
		}
		function updatePosition(scrollX, scrollY) {
			flickableItem.contentX = scrollX
			flickableItem.contentY = scrollY
		}

		Image {
			id: image
			objectName: "image"
			asynchronous: true
			fillMode: Image.PreserveAspectFit
			signal ready(int hMax, int vMax)
			signal changeMode()
			onStatusChanged: {
				if(image.status == Image.Ready) {
					ready(sourceSize.width - scroll.width, sourceSize.height - scroll.height);
					pageNumberBackgound.visible = true
				}
			}
			PinchArea {
				signal getScale(real scale)
				id: pinchArea
				objectName: "pinchArea"
				property real minScale:  0.33
				property real lastScale: 1.0

				width: image.width; height: image.height
				pinch.target: image
				pinch.minimumScale: minScale
				pinch.maximumScale: 3.0
				onPinchFinished: {
					getScale(pinch.scale)
				}
				MouseArea {
					id: mouseArea;
					objectName: "mouseArea";
					anchors.fill: parent;
					acceptedButtons: Qt.LeftButton

					onDoubleClicked: {
						if(mouse.button == Qt.LeftButton) {
							image.changeMode()
						}
					}

					onClicked: {
						if(mouse.button == Qt.LeftButton) {
							pageNumberBackgound.visible = true
						}
					}
				}
			}
		}
	}
	Rectangle {
		objectName: "pageNumberBackgound"
		id: pageNumberBackgound
		anchors.horizontalCenter: parent.horizontalCenter
		anchors.bottom: parent.bottom
		visible: false
		width: pageNumber.width
		height: pageNumber.height
		Text {
			objectName: "pageNumber"
			id: pageNumber
			text: ""
			font.pointSize: 24
			color: "black"
			anchors.centerIn: parent
		}
		Timer {
			interval: 2000; running: parent.visible; repeat: true
			onTriggered: parent.visible = false
		}
	}
	Component.onDestruction: destruct()
}
