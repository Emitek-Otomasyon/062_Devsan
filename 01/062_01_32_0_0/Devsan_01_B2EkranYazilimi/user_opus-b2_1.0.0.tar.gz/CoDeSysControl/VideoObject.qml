import QtQuick 2.5
import QtQuick.Controls 1.4
import QtQuick.Window 2.1

import org.freedesktop.gstreamer.GLVideoItem 1.0

Item
{
	id: window
	anchors.fill: parent
	opacity: 1.0

	signal destruct()

	Text {
	objectName: "waitText"
	text: "..."
	font.pointSize: 24
	color: "black"
	anchors.centerIn: parent
	}

	GstGLVideoItem
	{
		property alias flipX: myScale.xScale
		property alias flipY: myScale.yScale
		property alias originX: myScale.origin.x
		property alias originY: myScale.origin.y
		
		property alias myAngle: myRotation.angle
		property alias originXR: myRotation.origin.x
		property alias originYR: myRotation.origin.y
		
		width: parent.width
		height: parent.height
		id: video
		objectName: "videoItem"
		transform: [ 
			Scale { 
				id: myScale
			},
			Rotation { 
				id: myRotation
				axis { x: 0; y: 0; z: 1 }
			}
		]
		
		function setTransformation(mirror, rotation) {
			originX = width / 2;
			originY = height / 2;
			originXR = width / 2;
			originYR = height / 2;
			myAngle = rotation
			if (mirror == 0) {
				flipX = 1
				flipY = 1
			} else if (mirror == 1) {
				flipX = -1
				flipY = 1
			} else if (mirror == 2) {
				flipX = 1
				flipY = -1
			} else if (mirror == 3) {
				flipX = -1
				flipY = -1
			}
		}
	}
	Component.onDestruction: destruct()
}

